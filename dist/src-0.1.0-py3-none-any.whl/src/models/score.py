def fetch_score_list(competition_id, match_id, page, size):
    # mock data
    scores = [{
        'score': 3,
        'status': 'finished',
        'created_at': '2021-01-01',
        'started_at': "2021-01-01",
        'finished_at': "2021-01-01",
    }]
    return scores
