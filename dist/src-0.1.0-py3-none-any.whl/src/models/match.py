def fetch_participated_match_list_by_competition_id(competition_id):
    #mock data
    matches = [{"name": "match1"}, {"name": "match2"}]
    return matches
