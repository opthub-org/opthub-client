def fetch_participated_competition_list():
    # mock data
    competitions = [{
        'name': 'competition1',
        'matches': ['match1', 'match2']
    }, {
        'name': 'competition2',
        'matches': ['match1', 'match2']
    }]
    return competitions
